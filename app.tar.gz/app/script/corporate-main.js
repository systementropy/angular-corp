(function() {
    'use strict';

    angular.module('myApp.corporate-main', ['ngRoute'])

    .config(['$routeProvider',
        function($routeProvider) {
            $routeProvider.when('/corporate-main', {
                templateUrl: '/view/corporate-main.html',
                controller: 'CorporateMainCtrl'
            });
        }
    ])

    .controller('CorporateMainCtrl', ['$rootScope' ,'$scope', '$http','$timeout','$location','parallaxHelper','$window', function($rootScope,$scope, $http,$timeout,$location,parallaxHelper,$window) {
        $scope.openProfile = function(sec,status,index){
            console.log(sec,status,index);
            if (!status) {
                    $scope.openMap={
                        'Management':{},
                        'CNBC':{},
                        'News18':{},
                        'Digital':{},
                        'Print':{},
                    };
                    $scope.openMap[sec][index]=true;
            }else {
                $scope.openMap={
                    'Management':{},
                    'CNBC':{},
                    'News18':{},
                    'Digital':{},
                    'Print':{},
                };
            }
            
        }
        $scope.init = function(){
            $window.document.title='NETWORK18 | About Us';
            $scope.peopleData = {
                'Management':[
                    {
                        'name':"Rahul Joshi",
                        'text':"Rahul is the Managing Director and Group Editor-in-Chief of Network18. He has been associated with Network18 Group since September 2015.Prior to joining Network18, he worked as the Editorial Director of The Economic Times, Asia's largest selling financial daily. Rahul has done Masters in Management Studies from Narsee Monjee Institute of Management Studies (NMIMS), Mumbai University.",
                        'img':"/images/profile/rahuljoshi.png"
                    },{
                        'name':"Avinash Kaul",
                        'text':"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.",
                        'img':"/images/profile/avinashkaul.png"
                    },{
                        'name':"Joy Chakraborthy",
                        'text':"Revenue head for TV18 news channels, Joy is also CEO for Forbes India . Spanning a Media career of 26 years, Joy’s forte is advertising sales and revenue generation. In his previous roles, Joy was Director at the Times of India Group, CEO of TV Today, Executive Director at Zee Network and Executive Vice-President at Star India. Joy also holds an AMP Degree from Harvard Business School.",
                        'img':"/images/profile/JoyChakraborthy.png"
                    },{
                        'name':"Santosh Menon",
                        'text':"Santosh Menon heads editorial and content  for Network 18’s digital operations as Chief Content Officer and also plays a key role in integrating editorial operations across platforms and brands. A journalist with more than two decades of experience across continents, Santosh joined Network 18 in April 2016 from The Economic Times where he was Deputy Executive Editor and Head of News. Before that he worked for Reuters in London and reported from around Europe. At Network 18, he has driven editorial strategy and expansion across brands and spearheaded the creation of new properties.",
                        'img':"/images/profile/SantoshMenon.png"
                    },{
                        'name':"Manish Maheshwari",
                        'text':"Manish is CEO of Network18 Digital, which is the mobile and internet arm of Network18 Group, India's largest media and entertainment group serving content in 18 languages with 650 million television viewers and 105 million monthly unique digital visitors. Previously, Manish headed Flipkart's Seller Business and Ecosystem and worked at McKinsey in New York. He holds an MBA with honours from Wharton Business School.",
                        'img':"/images/profile/ManishMaheshwari.png"
                    },{
                        'name':"Puneet Singhvi",
                        'text':"Puneet is leading & overseeing Investments, M&As, Partnerships, Strategic Alliances and Business Development across all media platforms (Television, Telecom, Digital and Offline) within the Network18 group. He is also a part of the team at parent company, that evaluates and drives investment and alliance initiatives across technology and digital domain. Erstwhile, he has served as COO of Times Global Partners where he was responsible for overall strategy and growth.",
                        'img':"/images/profile/PuneetSinghvi.png"
                    },{
                        'name':"Anuj Gandhi",
                        'text':"Anuj Gandhi is the Group CEO of IndiaCast, a joint venture between TV18 and Viacom. Anuj heads a team of professionals for Traditional and New Media Platforms with a vast experience in Platform and Content Monetisation businesses in Linear (traditional TV channels) and Non-linear (VOD, Syndication etc.) forms. With a distinct understanding of the content distribution and platform business, Anuj is leading India's only Content Monetisation Company – IndiaCast",
                        'img':"/images/profile/profilepic.png"
                    },{
                        'name':"Rahul Kansal",
                        'text':"Rahul Kansal, Group Brand Advisor, helps the various business verticals of Network  18 with their brand-building and marketing strategies. He is also overseeing the company’s forthcoming entry into news publishing. Rahul is a veteran of media marketing, and was earlier Executive President of Bennett Coleman, serving as business head of The Times of India and the company’s language newspapers.",
                        'img':"/images/profile/RahulKansal.png"
                    },{
                        'name':"Priyanka Kaul",
                        'text':"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.",
                        'img':"/images/profile/PriyankaKaul.png"
                    },{
                        'name':"Ramesh Damani",
                        'text':"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.",
                        'img':"/images/profile/RameshDamani.png"
                    },{
                        'name':"Kshipra Jatana",
                        'text':"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.",
                        'img':"/images/profile/KshipraJatana.png"
                    },{
                        'name':"P Sakthivel",
                        'text':"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.",
                        'img':"/images/profile/profilepic.png"
                    },{
                        'name':"Rajat Nigam",
                        'text':"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.",
                        'img':"/images/profile/RajatNigam.png"
                    }
                ],
                'CNBC':[
                    {
                        'name':"Shereen Bhan",
                        'text':"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.",
                        'img':"/images/profile/sheerin.png"
                    },{
                        'name':"Udayan Mukherjee",
                        'text':"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.",
                        'img':"/images/profile/profilepic.png"
                    },{
                        'name':"Latha Venkatesh",
                        'text':"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.",
                        'img':"/images/profile/profilepic.png"
                    },{
                        'name':"Alok Joshi",
                        'text':"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.",
                        'img':"/images/profile/alokjoshi.png"
                    }
                ],
                'News18':[
                    {
                        'name':"Bhupendra Chaubey",
                        'text':"Bhupendra Chaubey is India’s most trusted political journalist on News television. A person who epitomises the rigour of journalism, in a world where opinions can be shaped in 100 characters , Bhupendra is the quintessential old world journalist who goes not just by his own gut but the ground level realities. He is the executive editor at CNN News18 and is the main political anchor for the network. He drives a team of bright political reporters across the country and hosts the channels flagship news show “Viewpoint. “. Having won national and international acclaim for his work, He brings with himself almost two decades of journalistic excellence",
                        'img':"/images/profile/Bhupendrachaubey.png"
                    },{
                        'name':"Anuradha Sengupta",
                        'text':"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.",
                        'img':"/images/profile/anuradhasengupta.png"
                    },{
                        'name':"Zakka Jacob",
                        'text':"Zakka Jacob is the Output Editor of CNN News18 where his role involves editorializing the channel’s daily news coverage. He leads a team of about 40 people giving editorial direction to the channel’s coverage, prioritizing & positioning of stories and delivering a cutting-edge to CNN News18’s staple of daily news. In addition to his Output role, he also anchors the 8 PM primetime show FaceOff. Zakka was awarded the Best News Anchor in Asia by the Asian Television Academy in 2016.",
                        'img':"/images/profile/zakkajacob.png"
                    },{
                        'name':"Sudeep Mukhia",
                        'text':"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.",
                        'img':"/images/profile/profilepic.png"
                    },{
                        'name':"Prabal Pratap Singh",
                        'text':"Prabal Pratap Singh is Managing Editor of News18 India, one of the leading hindi national news channel of India. It belongs to Network18 group. A journalist who comes with a background experience of The Pioneer and  Aaj Tak. A first Indian journalist to set foot on the war driven Afghanistan, whose reportage was acknowledged all across.  Be it war, terrorism, left wing extremism and election, he has been there reporting from ground zero for the print and television in his 25 years of journalistic career.",
                        'img':"/images/profile/Prabal.png"
                    },{
                        'name':"Kishore Ajwani",
                        'text':"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.",
                        'img':"/images/profile/KishoreAjwani.png"
                    },{
                        'name':"Amish Devgan",
                        'text':"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.",
                        'img':"/images/profile/amishdevgan.png"
                    },{
                        'name':"Sumit Awasthi",
                        'text':"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.",
                        'img':"/images/profile/profilepic.png"
                    },{
                        'name':"Rajesh Raina",
                        'text':"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.",
                        'img':"/images/profile/profilepic.png"
                    },{
                        'name':"Karthik Subramanian",
                        'text':"Karthik works with the team in south India to make the News 18 channels in Karnataka, Kerala and Tamil Nadu the number 1 in their respective markets. He also heads Standards and Practices for the Network 18 group. Karthik was previously the Editor (South) at The Economic Times.",
                        'img':"/images/profile/profilepic.png"
                    }
                ],
                'Digital':[
                    {
                        'name':"BV Rao",
                        'text':"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.",
                        'img':"/images/profile/profilepic.png"
                    },{
                        'name':"Santosh Nair",
                        'text':"Santosh Nair oversees moneycontrol.com’s editorial coverage spanning breaking news, analysis, research and videos. Formerly, he was Markets Editor at The Economic Times, where he was responsible for driving stock market coverage.",
                        'img':"/images/profile/profilepic.png"
                    },{
                        'name':"Praveen Thampi",
                        'text':"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.",
                        'img':"/images/profile/profilepic.png"
                    },{
                        'name':"Gaurav Kalra",
                        'text':"Gaurav Kalra is the Group Sports Editor at Network 18. He works across all existing brands and platforms with particular focus on the expansion of Cricketnext.com, the group’s flagship Cricket website. Reporters and editors of all existing sports verticals across the network converge with him in addition to their existing managers. He was previously Senior Editor at ESPNCricinfo and served as Sports Editor of the erstwhile CNN-IBN between 2005 to 2013.",
                        'img':"/images/profile/GauravKalra.png"
                    },{
                        'name':"Pravin Swami",
                        'text':"Praveen Swami is a is Group Consulting Editor for Network18, and a on regional security and intelligence issues. Described by the BBC as “one of India’s foremost commentators on Islamist terrorism”, he has won several major awards for his work.  He is the author of two books on the India-Pakistan conflict. He has earlier held key editorial positions at The Indian Express, The Hindu, and The Daily Telegraph, London.",
                        'img':"/images/profile/praveenswami.png"
                    }
                ],
                'Print':[
                    {
                        'name':"Brian Carvalho",
                        'text':"Brian is the group editor of the publishing business of the Network 18 group. He edits Forbes India, a fortnightly business magazine, and its digital avatar. Prior to this assignment, he led features at The Economic Times and edited the eclectic Sunday product, called The Economic Times Magazine.",
                        'img':"/images/profile/BrianCarvalho.png"
                    }
                ]
            }
            $scope.slickConfig = {
                centerMode: true,
                slidesToShow: 1,
                dots: true,
                autoPlay:true,
                responsive: [
                    {
                      breakpoint: 768,
                      settings: {
                        arrows: false,
                        centerMode: true,
                        centerPadding: '40px',
                        slidesToShow: 1
                      }
                    },
                    {
                      breakpoint: 480,
                      settings: {
                        arrows: false,
                        centerMode: true,
                        centerPadding: '40px',
                        slidesToShow: 1
                      }
                    }
                ]
            };
            $scope.fadeIn = parallaxHelper.createAnimator(0.15, 0, 1,-850);
            $scope.transY = parallaxHelper.createAnimator(0.4, 10, -10,-950);
            $scope.transYL = parallaxHelper.createAnimator(0.4, 20, -10,-850);
            $rootScope.hideHeader=false;
            $rootScope.hidefooter=false;
            $scope.openMap={
                'Management':{},
                'CNBC':{},
                'News18':{},
                'Digital':{},
                'Print':{},
            };
        };
        
        $scope.init();
    }]);
}());
